vopt -64 +acc -l elaborate.log -L xil_defaultlib -L xpm -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.SNN_top_0 xil_defaultlib.glbl -o SNN_top_0_opt
