# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "AXI4_ADDR_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "AXI4_DATA_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "AXI4_ID_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "AXI4_USER_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "LIF_NEURON_OVRFL_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NEURAL_ARRAY_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "OUTPUT_ARRAY_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SPK_ARRAY_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "WEIGHT_ADDR_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "WEIGHT_WIDTH" -parent ${Page_0}


}

proc update_PARAM_VALUE.AXI4_ADDR_WIDTH { PARAM_VALUE.AXI4_ADDR_WIDTH } {
	# Procedure called to update AXI4_ADDR_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXI4_ADDR_WIDTH { PARAM_VALUE.AXI4_ADDR_WIDTH } {
	# Procedure called to validate AXI4_ADDR_WIDTH
	return true
}

proc update_PARAM_VALUE.AXI4_DATA_WIDTH { PARAM_VALUE.AXI4_DATA_WIDTH } {
	# Procedure called to update AXI4_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXI4_DATA_WIDTH { PARAM_VALUE.AXI4_DATA_WIDTH } {
	# Procedure called to validate AXI4_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.AXI4_ID_WIDTH { PARAM_VALUE.AXI4_ID_WIDTH } {
	# Procedure called to update AXI4_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXI4_ID_WIDTH { PARAM_VALUE.AXI4_ID_WIDTH } {
	# Procedure called to validate AXI4_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.AXI4_USER_WIDTH { PARAM_VALUE.AXI4_USER_WIDTH } {
	# Procedure called to update AXI4_USER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXI4_USER_WIDTH { PARAM_VALUE.AXI4_USER_WIDTH } {
	# Procedure called to validate AXI4_USER_WIDTH
	return true
}

proc update_PARAM_VALUE.LIF_NEURON_OVRFL_WIDTH { PARAM_VALUE.LIF_NEURON_OVRFL_WIDTH } {
	# Procedure called to update LIF_NEURON_OVRFL_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LIF_NEURON_OVRFL_WIDTH { PARAM_VALUE.LIF_NEURON_OVRFL_WIDTH } {
	# Procedure called to validate LIF_NEURON_OVRFL_WIDTH
	return true
}

proc update_PARAM_VALUE.NEURAL_ARRAY_WIDTH { PARAM_VALUE.NEURAL_ARRAY_WIDTH } {
	# Procedure called to update NEURAL_ARRAY_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NEURAL_ARRAY_WIDTH { PARAM_VALUE.NEURAL_ARRAY_WIDTH } {
	# Procedure called to validate NEURAL_ARRAY_WIDTH
	return true
}

proc update_PARAM_VALUE.OUTPUT_ARRAY_WIDTH { PARAM_VALUE.OUTPUT_ARRAY_WIDTH } {
	# Procedure called to update OUTPUT_ARRAY_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.OUTPUT_ARRAY_WIDTH { PARAM_VALUE.OUTPUT_ARRAY_WIDTH } {
	# Procedure called to validate OUTPUT_ARRAY_WIDTH
	return true
}

proc update_PARAM_VALUE.SPK_ARRAY_WIDTH { PARAM_VALUE.SPK_ARRAY_WIDTH } {
	# Procedure called to update SPK_ARRAY_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SPK_ARRAY_WIDTH { PARAM_VALUE.SPK_ARRAY_WIDTH } {
	# Procedure called to validate SPK_ARRAY_WIDTH
	return true
}

proc update_PARAM_VALUE.WEIGHT_ADDR_WIDTH { PARAM_VALUE.WEIGHT_ADDR_WIDTH } {
	# Procedure called to update WEIGHT_ADDR_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.WEIGHT_ADDR_WIDTH { PARAM_VALUE.WEIGHT_ADDR_WIDTH } {
	# Procedure called to validate WEIGHT_ADDR_WIDTH
	return true
}

proc update_PARAM_VALUE.WEIGHT_WIDTH { PARAM_VALUE.WEIGHT_WIDTH } {
	# Procedure called to update WEIGHT_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.WEIGHT_WIDTH { PARAM_VALUE.WEIGHT_WIDTH } {
	# Procedure called to validate WEIGHT_WIDTH
	return true
}


proc update_MODELPARAM_VALUE.LIF_NEURON_OVRFL_WIDTH { MODELPARAM_VALUE.LIF_NEURON_OVRFL_WIDTH PARAM_VALUE.LIF_NEURON_OVRFL_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LIF_NEURON_OVRFL_WIDTH}] ${MODELPARAM_VALUE.LIF_NEURON_OVRFL_WIDTH}
}

proc update_MODELPARAM_VALUE.SPK_ARRAY_WIDTH { MODELPARAM_VALUE.SPK_ARRAY_WIDTH PARAM_VALUE.SPK_ARRAY_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SPK_ARRAY_WIDTH}] ${MODELPARAM_VALUE.SPK_ARRAY_WIDTH}
}

proc update_MODELPARAM_VALUE.NEURAL_ARRAY_WIDTH { MODELPARAM_VALUE.NEURAL_ARRAY_WIDTH PARAM_VALUE.NEURAL_ARRAY_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NEURAL_ARRAY_WIDTH}] ${MODELPARAM_VALUE.NEURAL_ARRAY_WIDTH}
}

proc update_MODELPARAM_VALUE.OUTPUT_ARRAY_WIDTH { MODELPARAM_VALUE.OUTPUT_ARRAY_WIDTH PARAM_VALUE.OUTPUT_ARRAY_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.OUTPUT_ARRAY_WIDTH}] ${MODELPARAM_VALUE.OUTPUT_ARRAY_WIDTH}
}

proc update_MODELPARAM_VALUE.WEIGHT_ADDR_WIDTH { MODELPARAM_VALUE.WEIGHT_ADDR_WIDTH PARAM_VALUE.WEIGHT_ADDR_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.WEIGHT_ADDR_WIDTH}] ${MODELPARAM_VALUE.WEIGHT_ADDR_WIDTH}
}

proc update_MODELPARAM_VALUE.WEIGHT_WIDTH { MODELPARAM_VALUE.WEIGHT_WIDTH PARAM_VALUE.WEIGHT_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.WEIGHT_WIDTH}] ${MODELPARAM_VALUE.WEIGHT_WIDTH}
}

proc update_MODELPARAM_VALUE.AXI4_ADDR_WIDTH { MODELPARAM_VALUE.AXI4_ADDR_WIDTH PARAM_VALUE.AXI4_ADDR_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXI4_ADDR_WIDTH}] ${MODELPARAM_VALUE.AXI4_ADDR_WIDTH}
}

proc update_MODELPARAM_VALUE.AXI4_DATA_WIDTH { MODELPARAM_VALUE.AXI4_DATA_WIDTH PARAM_VALUE.AXI4_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXI4_DATA_WIDTH}] ${MODELPARAM_VALUE.AXI4_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.AXI4_USER_WIDTH { MODELPARAM_VALUE.AXI4_USER_WIDTH PARAM_VALUE.AXI4_USER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXI4_USER_WIDTH}] ${MODELPARAM_VALUE.AXI4_USER_WIDTH}
}

proc update_MODELPARAM_VALUE.AXI4_ID_WIDTH { MODELPARAM_VALUE.AXI4_ID_WIDTH PARAM_VALUE.AXI4_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXI4_ID_WIDTH}] ${MODELPARAM_VALUE.AXI4_ID_WIDTH}
}

